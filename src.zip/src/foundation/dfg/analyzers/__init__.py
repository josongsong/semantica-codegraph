"""
Language-specific statement analyzers
"""

from .python_analyzer import PythonStatementAnalyzer

__all__ = ["PythonStatementAnalyzer"]
