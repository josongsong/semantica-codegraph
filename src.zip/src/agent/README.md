# Semantica Agent System

FSM-based code agent with 23 specialized modes for comprehensive code development tasks.

## Quick Start

```python
from src.agent import AgentFSM, AgentMode, Task, ModeContext

# Initialize FSM
fsm = AgentFSM()

# Register mode handlers (example)
from src.agent.modes import BaseModeHandler

class MyContextNavMode(BaseModeHandler):
    async def execute(self, task, context):
        # Implementation
        return self._create_result(
            data={"results": []},
            trigger="target_found"
        )

fsm.register(AgentMode.CONTEXT_NAV, MyContextNavMode(AgentMode.CONTEXT_NAV))

# Execute tasks
await fsm.transition(AgentMode.CONTEXT_NAV)
result = await fsm.execute(Task(query="find login function"))
```

## Architecture

### Core Components

#### 1. **AgentMode** (23 modes across 4 phases)

**Phase 0 - Core (6 modes)** - ✅ 5/6 Complete (83%):
- `IDLE`: Default state (basic only)
- ✅ `CONTEXT_NAV`: Code exploration and navigation
- ✅ `IMPLEMENTATION`: Code generation and modification
- ✅ `DEBUG`: Error analysis and fixing
- ✅ `TEST`: Test generation and execution
- ✅ `DOCUMENTATION`: Documentation generation

**Phase 1 - Advanced Workflow (7 modes)**:
- `DESIGN`: Architecture design
- `QA`: Code review and quality assurance
- `REFACTOR`: Code refactoring
- `MULTI_FILE_EDITING`: Large-scale changes
- `GIT_WORKFLOW`: Version control operations
- `AGENT_PLANNING`: Task planning and decomposition
- `IMPACT_ANALYSIS`: Change impact analysis

**Phase 2 - Specialization (5 modes)**:
- `MIGRATION`: Language/framework migration
- `DEPENDENCY_INTELLIGENCE`: Dependency analysis
- `SPEC_COMPLIANCE`: Specification compliance checking
- `VERIFICATION`: Formal verification
- `PERFORMANCE_PROFILING`: Performance analysis

**Phase 3 - Advanced Specialization (5 modes)**:
- `OPS_INFRA`: DevOps and infrastructure
- `ENVIRONMENT_REPRODUCTION`: Environment setup
- `BENCHMARK`: Performance benchmarking
- `DATA_ML_INTEGRATION`: ML pipeline integration
- `EXPLORATORY_RESEARCH`: Research and prototyping

#### 2. **AgentFSM** - Finite State Machine

Manages mode transitions and execution:

```python
fsm = AgentFSM()
fsm.register(mode, handler)
await fsm.transition(to_mode, trigger="reason")
result = await fsm.execute(task)
```

Key features:
- Automatic mode transitions based on result triggers
- Context preservation across transitions
- Transition history tracking
- Mode handler lifecycle management (enter/execute/exit)

#### 3. **ModeContext** - Shared State

Maintains state across mode transitions:

```python
context = ModeContext()
context.add_file("path/to/file.py")
context.add_symbol("MyClass")
context.add_pending_change({"file": "test.py", "action": "modify"})
```

Tracks:
- Current files and symbols
- Mode and action history
- Graph context (impact nodes, dependency chains)
- User preferences
- Pending changes and test results

#### 4. **ModeHandler Protocol**

Interface for mode implementations:

```python
class ModeHandler(Protocol):
    async def enter(self, context: ModeContext) -> None: ...
    async def execute(self, task: Task, context: ModeContext) -> Result: ...
    async def exit(self, context: ModeContext) -> None: ...
```

#### 5. **BaseModeHandler** - Abstract Base Class

Provides common utilities for mode implementations:

```python
from src.agent.modes import BaseModeHandler

class MyMode(BaseModeHandler):
    async def execute(self, task, context):
        # Your implementation
        return self._create_result(
            data={"key": "value"},
            trigger="next_mode",
            explanation="What happened",
            requires_approval=True
        )
```

## Auto-Transitions

The FSM supports automatic mode transitions based on result triggers:

| Trigger | Target Mode |
|---------|-------------|
| `target_found` | IMPLEMENTATION |
| `code_complete` | TEST |
| `tests_passed` | QA |
| `approved` | GIT_WORKFLOW |
| `error_found` | DEBUG |
| `needs_design` | DESIGN |
| `large_change` | MULTI_FILE_EDITING |
| `need_analysis` | IMPACT_ANALYSIS |

## Example Workflow

```python
# Scenario: "User t��� validate_email T� � t"

# 1. CONTEXT_NAV: Find User class
await fsm.transition(AgentMode.CONTEXT_NAV)
result1 = await fsm.execute(Task(query="find User class"))
# Returns: trigger="target_found"

# 2. Auto-transition to IMPLEMENTATION
# FSM automatically transitions based on trigger
result2 = await fsm.execute(Task(query="add validate_email method"))
# Returns: trigger="code_complete", requires_approval=True

# 3. Human approval
if result2.requires_approval:
    approved = await get_user_approval(result2)

# 4. Auto-transition to TEST
result3 = await fsm.execute(Task(query="create tests"))
```

## Development Status

###  Day 1 Complete (2024-11-25)

- [x] Core type definitions (`types.py`)
  - AgentMode enum (23 modes)
  - ApprovalLevel enum
  - Task, Result, ModeContext dataclasses
- [x] FSM engine (`fsm.py`)
  - Mode handler registration
  - Transition management
  - Auto-transition logic
  - Context preservation
- [x] Base mode handler (`modes/base.py`)
- [x] Comprehensive tests (12 tests, all passing)

### =� Next Steps

**Day 2**: Context Navigation Mode
- Implement hybrid search integration
- Symbol index integration
- File discovery and filtering

**Day 3**: Implementation Mode
- LLM integration for code generation
- Context builder integration
- Change management

**Day 4**: Orchestrator + Human-in-the-Loop
- Complete orchestrator
- Approval UI/CLI
- Change application

**Day 5**: Documentation + Demo
- Example scripts
- Usage documentation

## Testing

Run tests:

```bash
# All agent tests
pytest tests/agent/ -v

# Specific test file
pytest tests/agent/test_fsm.py -v

# With coverage
pytest tests/agent/ --cov=src/agent --cov-report=html
```

Current status: **93/93 tests passing** (Week 2 Day 4 - 4/6 Core Modes Complete)

## Integration with Semantica

The agent system leverages Semantica's unique capabilities:

- **GraphDocument**: Track code dependencies and impact
- **5-way Hybrid Search**: Multi-modal code search
- **Symbol Index**: Fast symbol lookup and resolution
- **Dependency Analysis**: Impact analysis using graph traversal
- **Semantic IR**: Deep code understanding

## References

- Planning docs: `_command_doc/15.�t�/`
  - `02.Agent_Modes_Priority_Plan.md` - Overall roadmap
  - `03.FSM_Design_Implementation.md` - FSM design details
  - `04.Quick_Start_Plan.md` - 5-day implementation plan

---

**Status**: Phase 0 Week 1 Day 1 Complete 
**Next**: Day 2 - Context Navigation Mode
