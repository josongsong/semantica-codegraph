"""Graph store adapters."""
