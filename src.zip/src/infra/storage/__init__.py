"""Relational storage adapters."""
