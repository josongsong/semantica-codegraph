"""Git provider adapters."""
