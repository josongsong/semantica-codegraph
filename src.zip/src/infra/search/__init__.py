"""Lexical search adapters."""
