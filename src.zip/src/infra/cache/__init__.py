"""Cache adapters (e.g., Redis)."""
