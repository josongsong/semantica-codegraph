"""LLM provider adapters."""
