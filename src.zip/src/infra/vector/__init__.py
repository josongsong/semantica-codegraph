"""Vector store adapters."""
