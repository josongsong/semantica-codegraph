"""Lexical search index adapters."""

from src.contexts.multi_index.infrastructure.lexical.adapter_zoekt import ZoektLexicalIndex

__all__ = [
    "ZoektLexicalIndex",
]
