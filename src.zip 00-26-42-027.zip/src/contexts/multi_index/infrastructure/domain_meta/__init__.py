"""Domain metadata index adapters."""

__all__: list[str] = []
