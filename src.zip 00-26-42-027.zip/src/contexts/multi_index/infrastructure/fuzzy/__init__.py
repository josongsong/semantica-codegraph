"""Fuzzy search index adapters."""

__all__: list[str] = []
