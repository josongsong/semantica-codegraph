"""
Semantica CodeGraph CLI

Command-line interface for code indexing and search.
"""

from src.cli.main import app, main

__all__ = ["app", "main"]
