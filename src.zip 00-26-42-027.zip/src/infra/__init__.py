"""Infrastructure layer adapters."""

__all__: list[str] = []
