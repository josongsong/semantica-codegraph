"""Git provider adapters."""

from src.infra.git.git_cli import GitCLIAdapter

__all__ = [
    "GitCLIAdapter",
]
