"""Relational storage adapters."""

from src.infra.storage.postgres import PostgresStore

__all__ = [
    "PostgresStore",
]
